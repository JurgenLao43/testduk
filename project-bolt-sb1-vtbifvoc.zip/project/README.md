# TaskCash iOS

A React Native/Expo app that pays users for completing brand-sponsored micro-tasks.

## Features

- 🍎 **Sign In with Apple** - Secure authentication with email fallback
- 💰 **Task Marketplace** - Complete surveys, games, offers, and receipt scans for cash
- 💳 **Real Withdrawals** - Cash out via PayPal or bank transfer (minimum $1.00)
- 👥 **Referral Program** - Earn $10 for each friend who withdraws
- 📊 **Real-time Wallet** - Track earnings with live balance updates
- 🎯 **Native Task Player** - Multi-step tasks with auto-save drafts
- 📱 **iOS-Optimized** - Follows Apple's Human Interface Guidelines

## Tech Stack

- **Framework**: Expo SDK 53 + React Native 0.79
- **Language**: TypeScript (strict mode)
- **State Management**: Zustand
- **Data Fetching**: TanStack Query
- **Navigation**: Expo Router
- **Styling**: StyleSheet with theme system
- **Database**: SQLite (offline-first)
- **Real-time**: Socket.io
- **Testing**: Jest + React Native Testing Library

## Getting Started

### Prerequisites

- Node.js 18+
- iOS Simulator or physical iOS device
- Expo CLI

### Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/taskcash-ios.git
cd taskcash-ios

# Install dependencies
npm install

# Start the development server
npm run dev
```

### Building for iOS

```bash
# Development build
eas build --profile dev-ios --platform ios

# Production build for TestFlight
eas build --profile production-ios --platform ios
```

## Project Structure

```
app/
├── (auth)/           # Authentication screens
├── (tabs)/           # Main tab navigation
├── task/             # Task player modal
└── _layout.tsx       # Root layout

components/
├── ui/               # Reusable UI components
├── charts/           # Data visualization
└── ...               # Feature-specific components

store/                # Zustand state management
services/             # API and business logic
utils/                # Helper functions
constants/            # Theme and configuration
```

## Environment Variables

Create a `.env` file in the root directory:

```env
EXPO_PUBLIC_API_URL=https://api.taskcash.app/v1
EXPO_PUBLIC_SOCKET_URL=wss://api.taskcash.app
```

## Testing

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage
```

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, email support@taskcash.app or create an issue in this repository.