export interface Task {
  id: string;
  title: string;
  description?: string;
  brandLogo: string;
  payout: number;
  estimatedMinutes: number;
  tag: 'survey' | 'game' | 'offer' | 'receipt';
  featured: boolean;
  steps?: TaskStep[];
}

export interface TaskStep {
  id: string;
  type: 'single-choice' | 'multi-choice' | 'text' | 'photo' | 'rating' | 'link';
  question: string;
  required: boolean;
  options?: string[];
  validation?: {
    minLength?: number;
    maxLength?: number;
    pattern?: string;
  };
}

export interface TaskSubmission {
  taskId: string;
  answers: Record<string, any>;
  submittedAt: string;
}