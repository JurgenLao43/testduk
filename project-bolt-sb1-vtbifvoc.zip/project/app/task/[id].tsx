import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useLocalSearchParams, router, Stack } from 'expo-router';
import { useTheme } from '@/constants/theme';
import { useTasksStore } from '@/store/tasks';
import { useWalletStore } from '@/store/wallet';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { TaskStepRenderer } from '@/components/TaskStepRenderer';
import { formatCurrency } from '@/utils/money';
import { Clock } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

export default function TaskPlayerScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const theme = useTheme();
  const { currentTask, fetchTask, submitTask, loadDraft, saveDraft } = useTasksStore();
  const { updateBalance, addTransaction } = useWalletStore();
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      fetchTask(id);
      // Load saved draft
      const draft = loadDraft(id);
      if (draft) {
        setAnswers(draft);
      }
    }
  }, [id]);

  // Auto-save draft every 2 seconds
  useEffect(() => {
    if (id && Object.keys(answers).length > 0) {
      const timer = setTimeout(() => {
        saveDraft(id, answers);
      }, 2000);
      
      return () => clearTimeout(timer);
    }
  }, [answers, id]);

  const handleStepAnswer = (stepId: string, answer: any) => {
    setAnswers(prev => ({ ...prev, [stepId]: answer }));
  };

  const handleNext = () => {
    if (currentTask && currentStepIndex < currentTask.steps!.length - 1) {
      setCurrentStepIndex(prev => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handleSubmit = async () => {
    if (!id || !currentTask) return;

    try {
      setIsSubmitting(true);
      const result = await submitTask(id, answers);
      
      // Haptic feedback for success
      if (Haptics) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      
      // Update wallet
      updateBalance(result.newBalance);
      addTransaction({
        id: result.txId,
        type: 'task_completed',
        amount: result.credit,
        description: `Completed: ${currentTask.title}`,
        timestamp: new Date().toISOString(),
        status: 'completed',
      });

      Alert.alert(
        'Task Completed!',
        `You earned ${formatCurrency(result.credit)}!`,
        [{ text: 'Continue', onPress: () => router.back() }]
      );
    } catch (error: any) {
      Alert.alert('Submission Failed', error.message || 'Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!currentTask) {
    return (
      <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
        <Stack.Screen 
          options={{
            title: 'Loading...',
            headerStyle: { backgroundColor: theme.colors.surface },
            headerTitleStyle: { color: theme.colors.textPrimary },
          }}
        />
        <Text>Loading task...</Text>
      </View>
    );
  }

  const currentStep = currentTask.steps?.[currentStepIndex];
  const progress = currentTask.steps ? (currentStepIndex + 1) / currentTask.steps.length : 1;

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <Stack.Screen 
        options={{
          title: currentTask.title,
          headerStyle: { backgroundColor: theme.colors.surface },
          headerTitleStyle: { 
            color: theme.colors.textPrimary,
            fontSize: 18,
            fontWeight: '600',
          },
          headerRight: () => (
            <View style={styles.headerRight}>
              <Clock size={14} color={theme.colors.textSecondary} />
              <Text style={[styles.etaText, { color: theme.colors.textSecondary }]}>
                {currentTask.estimatedMinutes}m
              </Text>
              <Text style={[styles.payoutText, { color: theme.colors.accent }]}>
                {formatCurrency(currentTask.payout)}
              </Text>
            </View>
          ),
        }}
      />

      <View style={[styles.progressBar, { backgroundColor: theme.colors.border }]}>
        <View 
          style={[
            styles.progressFill, 
            { 
              backgroundColor: theme.colors.primary,
              width: `${progress * 100}%`,
            }
          ]} 
        />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {currentStep && (
          <TaskStepRenderer
            step={currentStep}
            answer={answers[currentStep.id]}
            onAnswer={(answer) => handleStepAnswer(currentStep.id, answer)}
          />
        )}
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: theme.colors.surface }]}>
        <PrimaryButton
          title={currentStepIndex === (currentTask.steps?.length || 1) - 1 ? 'Submit Task' : 'Continue'}
          onPress={handleNext}
          disabled={currentStep?.required && !answers[currentStep.id]}
          loading={isSubmitting}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginRight: 16,
  },
  etaText: {
    fontSize: 13,
    fontWeight: '500',
  },
  payoutText: {
    fontSize: 14,
    fontWeight: '700',
  },
  progressBar: {
    height: 3,
    marginHorizontal: 16,
  },
  progressFill: {
    height: '100%',
    borderRadius: 1.5,
  },
  content: {
    flex: 1,
    padding: 24,
  },
  footer: {
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
});