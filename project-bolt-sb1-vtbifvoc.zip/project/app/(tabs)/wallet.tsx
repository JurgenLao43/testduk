import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { useTheme } from '@/constants/theme';
import { useWalletStore } from '@/store/wallet';
import { BalanceChart } from '@/components/charts/BalanceChart';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { TransactionList } from '@/components/TransactionList';
import { WithdrawModal } from '@/components/WithdrawModal';
import { formatCurrency } from '@/utils/money';
import { TrendingUp, Download } from 'lucide-react-native';

export default function WalletScreen() {
  const theme = useTheme();
  const [showWithdrawModal, setShowWithdrawModal] = useState(false);
  const { balance, transactions, isLoading } = useWalletStore();

  const canWithdraw = balance >= 1.0;

  const handleWithdraw = () => {
    if (!canWithdraw) {
      Alert.alert(
        'Minimum Balance Required',
        'You need at least $1.00 to withdraw funds.'
      );
      return;
    }
    setShowWithdrawModal(true);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={[styles.balanceCard, { backgroundColor: theme.colors.surface }]}>
          <View style={styles.balanceHeader}>
            <Text style={[styles.balanceLabel, { color: theme.colors.textSecondary }]}>
              Available Balance
            </Text>
            <TrendingUp size={20} color={theme.colors.primary} />
          </View>
          
          <Text style={[styles.balanceAmount, { color: theme.colors.textPrimary }]}>
            {formatCurrency(balance)}
          </Text>

          <PrimaryButton
            title="Withdraw Funds"
            onPress={handleWithdraw}
            disabled={!canWithdraw}
            style={[styles.withdrawButton, !canWithdraw && styles.withdrawButtonDisabled]}
            icon={<Download size={20} color={canWithdraw ? theme.colors.surface : theme.colors.textSecondary} />}
          />

          {!canWithdraw && (
            <Text style={[styles.withdrawHint, { color: theme.colors.textSecondary }]}>
              Earn ${formatCurrency(1.0 - balance, false)} more to withdraw
            </Text>
          )}
        </View>

        <View style={[styles.chartCard, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.chartTitle, { color: theme.colors.textPrimary }]}>
            Earnings (14 days)
          </Text>
          <BalanceChart />
        </View>

        <View style={[styles.transactionsCard, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.transactionsTitle, { color: theme.colors.textPrimary }]}>
            Recent Activity
          </Text>
          <TransactionList transactions={transactions} />
        </View>
      </ScrollView>

      <WithdrawModal
        visible={showWithdrawModal}
        onClose={() => setShowWithdrawModal(false)}
        balance={balance}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    padding: 16,
  },
  balanceCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  balanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  balanceLabel: {
    fontSize: 16,
    fontWeight: '500',
  },
  balanceAmount: {
    fontSize: 48,
    fontWeight: '700',
    marginBottom: 24,
  },
  withdrawButton: {
    marginBottom: 8,
  },
  withdrawButtonDisabled: {
    opacity: 0.5,
  },
  withdrawHint: {
    fontSize: 13,
    textAlign: 'center',
  },
  chartCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  transactionsCard: {
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  transactionsTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
});