import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  Linking,
} from 'react-native';
import { router } from 'expo-router';
import { useTheme } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';
import { useUIStore } from '@/store/ui';
import { 
  User, 
  Bell, 
  Vibrate, 
  Moon, 
  FileText, 
  Mail, 
  LogOut,
  Trash2,
  ChevronRight,
} from 'lucide-react-native';

export default function SettingsScreen() {
  const theme = useTheme();
  const { user, signOut } = useAuthStore();
  const { 
    pushNotificationsEnabled, 
    hapticsEnabled, 
    darkModeOverride,
    togglePushNotifications,
    toggleHaptics,
    toggleDarkModeOverride,
  } = useUIStore();

  const handleSignOut = () => {
    Alert.alert(
      'Sign Out',
      'Are you sure you want to sign out?',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Sign Out', 
          style: 'destructive',
          onPress: () => {
            signOut();
            router.replace('/(auth)');
          },
        },
      ]
    );
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Delete Account',
      'This action cannot be undone. All your data will be permanently deleted.',
      [
        { text: 'Cancel', style: 'cancel' },
        { 
          text: 'Delete', 
          style: 'destructive',
          onPress: () => {
            // TODO: Implement account deletion
            Alert.alert('Feature Coming Soon', 'Account deletion will be available in the next update.');
          },
        },
      ]
    );
  };

  const handleContactSupport = () => {
    const subject = 'TaskCash Support Request';
    const body = `Device: ${user?.deviceInfo || 'Unknown'}\nApp Version: 1.0.0\n\nDescribe your issue:\n`;
    
    Linking.openURL(`mailto:support@taskcash.app?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`);
  };

  const openLegalDoc = (doc: 'terms' | 'privacy') => {
    const url = doc === 'terms' 
      ? 'https://taskcash.app/terms' 
      : 'https://taskcash.app/privacy';
    Linking.openURL(url);
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={[styles.profileCard, { backgroundColor: theme.colors.surface }]}>
          <TouchableOpacity 
            style={styles.profileHeader}
            accessibilityLabel="View profile details"
          >
            <View style={[styles.avatar, { backgroundColor: theme.colors.primary }]}>
              <User size={24} color={theme.colors.surface} />
            </View>
            <View style={styles.profileInfo}>
              <Text style={[styles.profileName, { color: theme.colors.textPrimary }]}>
                {user?.displayName || 'TaskCash User'}
              </Text>
              <Text style={[styles.profileEmail, { color: theme.colors.textSecondary }]}>
                {user?.email || 'user@example.com'}
              </Text>
            </View>
            <ChevronRight size={20} color={theme.colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={[styles.section, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.sectionTitle, { color: theme.colors.textPrimary }]}>
            Preferences
          </Text>
          
          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Bell size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.settingLabel, { color: theme.colors.textPrimary }]}>
                Push Notifications
              </Text>
            </View>
            <Switch
              value={pushNotificationsEnabled}
              onValueChange={togglePushNotifications}
              trackColor={{ false: theme.colors.border, true: theme.colors.primaryLight }}
              thumbColor={pushNotificationsEnabled ? theme.colors.primary : theme.colors.textSecondary}
              accessibilityLabel="Toggle push notifications"
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Vibrate size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.settingLabel, { color: theme.colors.textPrimary }]}>
                Haptic Feedback
              </Text>
            </View>
            <Switch
              value={hapticsEnabled}
              onValueChange={toggleHaptics}
              trackColor={{ false: theme.colors.border, true: theme.colors.primaryLight }}
              thumbColor={hapticsEnabled ? theme.colors.primary : theme.colors.textSecondary}
              accessibilityLabel="Toggle haptic feedback"
            />
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Moon size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.settingLabel, { color: theme.colors.textPrimary }]}>
                Dark Mode Override
              </Text>
            </View>
            <Switch
              value={darkModeOverride}
              onValueChange={toggleDarkModeOverride}
              trackColor={{ false: theme.colors.border, true: theme.colors.primaryLight }}
              thumbColor={darkModeOverride ? theme.colors.primary : theme.colors.textSecondary}
              accessibilityLabel="Toggle dark mode override"
            />
          </View>
        </View>

        <View style={[styles.section, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.sectionTitle, { color: theme.colors.textPrimary }]}>
            Legal & Support
          </Text>
          
          <TouchableOpacity
            style={styles.settingItem}
            onPress={() => openLegalDoc('terms')}
            accessibilityLabel="View Terms of Service"
          >
            <View style={styles.settingLeft}>
              <FileText size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.settingLabel, { color: theme.colors.textPrimary }]}>
                Terms of Service
              </Text>
            </View>
            <ChevronRight size={20} color={theme.colors.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.settingItem}
            onPress={() => openLegalDoc('privacy')}
            accessibilityLabel="View Privacy Policy"
          >
            <View style={styles.settingLeft}>
              <FileText size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.settingLabel, { color: theme.colors.textPrimary }]}>
                Privacy Policy
              </Text>
            </View>
            <ChevronRight size={20} color={theme.colors.textSecondary} />
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.settingItem}
            onPress={handleContactSupport}
            accessibilityLabel="Contact support team"
          >
            <View style={styles.settingLeft}>
              <Mail size={20} color={theme.colors.textSecondary} />
              <Text style={[styles.settingLabel, { color: theme.colors.textPrimary }]}>
                Contact Support
              </Text>
            </View>
            <ChevronRight size={20} color={theme.colors.textSecondary} />
          </TouchableOpacity>
        </View>

        <View style={[styles.section, { backgroundColor: theme.colors.surface }]}>
          <TouchableOpacity
            style={styles.settingItem}
            onPress={handleSignOut}
            accessibilityLabel="Sign out of your account"
          >
            <View style={styles.settingLeft}>
              <LogOut size={20} color={theme.colors.error} />
              <Text style={[styles.settingLabel, { color: theme.colors.error }]}>
                Sign Out
              </Text>
            </View>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.settingItem}
            onPress={handleDeleteAccount}
            accessibilityLabel="Delete your account permanently"
          >
            <View style={styles.settingLeft}>
              <Trash2 size={20} color={theme.colors.error} />
              <Text style={[styles.settingLabel, { color: theme.colors.error }]}>
                Delete Account
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  profileCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 2,
  },
  profileEmail: {
    fontSize: 14,
  },
  section: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    marginLeft: 12,
  },
});