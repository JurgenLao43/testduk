import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import { useTheme } from '@/constants/theme';
import { useTasksQuery } from '@/hooks/useTasks';
import { TaskCard } from '@/components/TaskCard';
import { TaskSkeleton } from '@/components/TaskSkeleton';
import { EmptyState } from '@/components/EmptyState';
import { Task } from '@/types/task';

const TABS = [
  { id: 'featured', label: 'Featured' },
  { id: 'high-pay', label: 'High Pay' },
  { id: 'new', label: 'New' },
];

export default function TasksScreen() {
  const theme = useTheme();
  const [activeTab, setActiveTab] = useState('featured');
  const { data, isLoading, refetch, fetchNextPage, hasNextPage } = useTasksQuery(activeTab);

  const tasks = data?.pages.flatMap(page => page.items) || [];

  const handleRefresh = useCallback(() => {
    refetch();
  }, [refetch]);

  const handleLoadMore = useCallback(() => {
    if (hasNextPage) {
      fetchNextPage();
    }
  }, [hasNextPage, fetchNextPage]);

  const handleTaskPress = (task: Task) => {
    router.push(`/task/${task.id}`);
  };

  const renderTask = ({ item }: { item: Task }) => (
    <TaskCard task={item} onPress={() => handleTaskPress(item)} />
  );

  const renderSkeleton = () => (
    <View>
      {Array.from({ length: 5 }).map((_, index) => (
        <TaskSkeleton key={index} />
      ))}
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={[styles.tabContainer, { backgroundColor: theme.colors.surface }]}>
          {TABS.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              style={[
                styles.tab,
                activeTab === tab.id && { backgroundColor: theme.colors.primary },
              ]}
              onPress={() => setActiveTab(tab.id)}
            >
              <Text
                style={[
                  styles.tabText,
                  {
                    color: activeTab === tab.id 
                      ? theme.colors.surface 
                      : theme.colors.textSecondary,
                  },
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          ))}
      </View>

      {isLoading ? (
        renderSkeleton()
      ) : tasks.length === 0 ? (
        <EmptyState
          title="No tasks available"
          description="Check back later for new earning opportunities"
          actionText="Refresh"
          onAction={handleRefresh}
        />
      ) : (
        <FlatList
          data={tasks}
          renderItem={renderTask}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.taskList}
          refreshControl={
            <RefreshControl
              refreshing={false}
              onRefresh={handleRefresh}
              tintColor={theme.colors.primary}
            />
          }
          onEndReached={handleLoadMore}
          onEndReachedThreshold={0.5}
          showsVerticalScrollIndicator={false}
          windowSize={10}
          initialNumToRender={8}
          maxToRenderPerBatch={5}
          removeClippedSubviews={true}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  tabContainer: {
    flexDirection: 'row',
    backgroundColor: '#F5F5F7',
    borderRadius: 8,
    padding: 4,
    marginHorizontal: 16,
    marginVertical: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  tab: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 6,
    alignItems: 'center',
  },
  tabText: {
    fontSize: 14,
    fontWeight: '500',
  },
  taskList: {
    padding: 16,
  },
});