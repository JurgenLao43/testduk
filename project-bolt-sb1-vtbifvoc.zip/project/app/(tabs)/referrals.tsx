import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Share,
  Alert,
} from 'react-native';
import { useTheme } from '@/constants/theme';
import { useAuthStore } from '@/store/auth';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { formatCurrency } from '@/utils/money';
import { Users, Share2, Copy } from 'lucide-react-native';
import * as Clipboard from 'expo-clipboard';

export default function ReferralsScreen() {
  const theme = useTheme();
  const { user } = useAuthStore();
  
  // Mock data - would come from API
  const referralStats = {
    code: 'TC4K2M',
    invitesSent: 12,
    converted: 3,
    earnings: 30.0,
  };

  const handleCopyCode = async () => {
    await Clipboard.setStringAsync(referralStats.code);
    Alert.alert('Copied!', 'Referral code copied to clipboard');
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Join me on TaskCash and earn money completing simple tasks! Use my code ${referralStats.code} and we both get $10 when you make your first withdrawal. Download: https://taskcash.app/ref/${referralStats.code}`,
        url: `https://taskcash.app/ref/${referralStats.code}`,
      });
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: theme.colors.background }]}>
      <View style={styles.content}>
        <View style={[styles.codeCard, { backgroundColor: theme.colors.surface }]}>
          <View style={styles.codeHeader}>
            <Users size={24} color={theme.colors.primary} />
            <Text style={[styles.codeTitle, { color: theme.colors.textPrimary }]}>
              Your Referral Code
            </Text>
          </View>
          
          <View style={styles.codeContainer}>
            <Text style={[styles.code, { color: theme.colors.primary }]}>
              {referralStats.code}
            </Text>
            <TouchableOpacity
              style={[styles.copyButton, { backgroundColor: theme.colors.primaryLight }]}
              onPress={handleCopyCode}
              accessibilityLabel="Copy referral code to clipboard"
            >
              <Copy size={16} color={theme.colors.surface} />
            </TouchableOpacity>
          </View>

          <Text style={[styles.codeDescription, { color: theme.colors.textSecondary }]}>
            Share your code and earn $10 for each friend who withdraws
          </Text>

          <PrimaryButton
            title="Share with Friends"
            onPress={handleShare}
            icon={<Share2 size={20} color={theme.colors.surface} />}
            style={styles.shareButton}
          />
        </View>

        <View style={[styles.statsCard, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.statsTitle, { color: theme.colors.textPrimary }]}>
            Referral Stats
          </Text>
          
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: theme.colors.textPrimary }]}>
                {referralStats.invitesSent}
              </Text>
              <Text style={[styles.statLabel, { color: theme.colors.textSecondary }]}>
                Invites Sent
              </Text>
            </View>
            
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: theme.colors.textPrimary }]}>
                {referralStats.converted}
              </Text>
              <Text style={[styles.statLabel, { color: theme.colors.textSecondary }]}>
                Friends Joined
              </Text>
            </View>
            
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: theme.colors.accent }]}>
                {formatCurrency(referralStats.earnings)}
              </Text>
              <Text style={[styles.statLabel, { color: theme.colors.textSecondary }]}>
                Total Earned
              </Text>
            </View>
          </View>
        </View>

        <View style={[styles.howItWorksCard, { backgroundColor: theme.colors.surface }]}>
          <Text style={[styles.howItWorksTitle, { color: theme.colors.textPrimary }]}>
            How It Works
          </Text>
          
          <View style={styles.stepsList}>
            <View style={styles.step}>
              <View style={[styles.stepNumber, { backgroundColor: theme.colors.primary }]}>
                <Text style={[styles.stepNumberText, { color: theme.colors.surface }]}>1</Text>
              </View>
              <Text style={[styles.stepText, { color: theme.colors.textPrimary }]}>
                Share your referral code with friends
              </Text>
            </View>
            
            <View style={styles.step}>
              <View style={[styles.stepNumber, { backgroundColor: theme.colors.primary }]}>
                <Text style={[styles.stepNumberText, { color: theme.colors.surface }]}>2</Text>
              </View>
              <Text style={[styles.stepText, { color: theme.colors.textPrimary }]}>
                They sign up and complete tasks
              </Text>
            </View>
            
            <View style={styles.step}>
              <View style={[styles.stepNumber, { backgroundColor: theme.colors.primary }]}>
                <Text style={[styles.stepNumberText, { color: theme.colors.surface }]}>3</Text>
              </View>
              <Text style={[styles.stepText, { color: theme.colors.textPrimary }]}>
                When they withdraw, you both get $10!
              </Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  codeCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  codeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  codeTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginLeft: 8,
  },
  codeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  code: {
    fontSize: 24,
    fontWeight: '700',
    letterSpacing: 2,
    marginRight: 12,
  },
  copyButton: {
    width: 32,
    height: 32,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  codeDescription: {
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  shareButton: {
    marginTop: 8,
  },
  statsCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 13,
    textAlign: 'center',
  },
  howItWorksCard: {
    borderRadius: 16,
    padding: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  howItWorksTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  stepsList: {
    gap: 16,
  },
  step: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  stepNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  stepNumberText: {
    fontSize: 12,
    fontWeight: '600',
  },
  stepText: {
    fontSize: 16,
    flex: 1,
  },
});