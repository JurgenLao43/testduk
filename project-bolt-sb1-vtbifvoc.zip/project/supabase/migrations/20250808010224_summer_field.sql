-- TaskCash SQLite Schema v1
-- Local caching and offline storage

-- Task drafts for auto-save functionality
CREATE TABLE IF NOT EXISTS task_drafts (
  task_id TEXT PRIMARY KEY,
  answers TEXT NOT NULL, -- JSON string
  last_saved TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Transaction history cache
CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY,
  type TEXT NOT NULL,
  amount REAL NOT NULL,
  description TEXT NOT NULL,
  timestamp TEXT NOT NULL,
  status TEXT NOT NULL,
  synced INTEGER DEFAULT 0
);

-- User preferences
CREATE TABLE IF NOT EXISTS user_preferences (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Device fingerprint for fraud prevention
CREATE TABLE IF NOT EXISTS device_info (
  id INTEGER PRIMARY KEY,
  device_id TEXT UNIQUE NOT NULL,
  model TEXT,
  os_version TEXT,
  app_version TEXT,
  first_seen TEXT DEFAULT CURRENT_TIMESTAMP,
  last_seen TEXT DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_transactions_timestamp ON transactions(timestamp);
CREATE INDEX IF NOT EXISTS idx_task_drafts_last_saved ON task_drafts(last_saved);