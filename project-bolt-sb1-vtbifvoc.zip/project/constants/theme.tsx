import React, { createContext, useContext, ReactNode } from 'react';
import { useColorScheme } from 'react-native';

export interface Theme {
  colors: {
    primary: string;
    primaryLight: string;
    accent: string;
    surface: string;
    background: string;
    textPrimary: string;
    textSecondary: string;
    border: string;
    error: string;
    success: string;
    warning: string;
  };
  spacing: {
    xs: number;
    sm: number;
    md: number;
    lg: number;
    xl: number;
    xxl: number;
  };
  typography: {
    display1: {
      fontSize: number;
      lineHeight: number;
      fontWeight: '600';
    };
    title1: {
      fontSize: number;
      lineHeight: number;
      fontWeight: '600';
    };
    body1: {
      fontSize: number;
      lineHeight: number;
      fontWeight: '400';
    };
    caption1: {
      fontSize: number;
      lineHeight: number;
      fontWeight: '400';
    };
  };
}

const lightTheme: Theme = {
  colors: {
    primary: '#4E44FF',
    primaryLight: '#716AFF',
    accent: '#FFB400',
    surface: '#FFFFFF',
    background: '#F5F5F7',
    textPrimary: '#0D0D0D',
    textSecondary: '#666A75',
    border: '#E5E5E7',
    error: '#FF3B30',
    success: '#34C759',
    warning: '#FF9500',
  },
  spacing: {
    xs: 4,
    sm: 8,
    md: 16,
    lg: 24,
    xl: 32,
    xxl: 48,
  },
  typography: {
    display1: {
      fontSize: 32,
      lineHeight: 38,
      fontWeight: '600',
    },
    title1: {
      fontSize: 24,
      lineHeight: 30,
      fontWeight: '600',
    },
    body1: {
      fontSize: 16,
      lineHeight: 24,
      fontWeight: '400',
    },
    caption1: {
      fontSize: 13,
      lineHeight: 18,
      fontWeight: '400',
    },
  },
};

const darkTheme: Theme = {
  ...lightTheme,
  colors: {
    ...lightTheme.colors,
    surface: '#1C1C1E',
    background: '#0C0C0E',
    textPrimary: '#FFFFFF',
    textSecondary: '#98989D',
    border: '#38383A',
  },
};

const ThemeContext = createContext<Theme>(lightTheme);

interface ThemeProviderProps {
  children: ReactNode;
}

export function ThemeProvider({ children }: ThemeProviderProps) {
  const colorScheme = useColorScheme();
  const theme = colorScheme === 'dark' ? darkTheme : lightTheme;

  return (
    <ThemeContext.Provider value={theme}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme(): Theme {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}