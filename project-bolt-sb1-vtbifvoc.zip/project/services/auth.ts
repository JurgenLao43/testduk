import * as AppleAuthentication from 'expo-apple-authentication';
import { api } from './api';

interface AuthResponse {
  token: string;
  refreshToken: string;
  user: {
    id: string;
    email: string;
    displayName?: string;
    avatar?: string;
    referralCode: string;
    deviceInfo?: string;
  };
}

class AuthService {
  async signInWithApple(credential: AppleAuthentication.AppleAuthenticationCredential): Promise<AuthResponse> {
    try {
      const response = await api.post('/auth/apple', {
        identityToken: credential.identityToken,
        authorizationCode: credential.authorizationCode,
        user: credential.fullName ? {
          firstName: credential.fullName.givenName,
          lastName: credential.fullName.familyName,
        } : null,
      });
      
      return response.data;
    } catch (error) {
      console.error('Apple sign in error:', error);
      throw new Error('Failed to sign in with Apple');
    }
  }

  async sendMagicLink(email: string): Promise<void> {
    try {
      await api.post('/auth/magic-link', { email });
    } catch (error) {
      console.error('Magic link error:', error);
      throw new Error('Failed to send magic link');
    }
  }

  async validateToken(token: string): Promise<AuthResponse['user']> {
    try {
      const response = await api.get('/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      
      return response.data.user;
    } catch (error) {
      console.error('Token validation error:', error);
      throw new Error('Invalid token');
    }
  }

  async refreshToken(refreshToken: string): Promise<{ token: string; refreshToken: string }> {
    try {
      const response = await api.post('/auth/refresh', { refreshToken });
      return response.data;
    } catch (error) {
      console.error('Token refresh error:', error);
      throw new Error('Failed to refresh token');
    }
  }
}

export const authService = new AuthService();