import { api } from './api';
import { Task, TaskSubmission } from '@/types/task';

interface TasksResponse {
  items: Task[];
  nextCursor?: string;
}

interface TaskSubmissionResponse {
  credit: number;
  txId: string;
  newBalance: number;
}

class TaskService {
  async getTasks(category: string, cursor?: string): Promise<TasksResponse> {
    try {
      const params = new URLSearchParams();
      params.append('category', category);
      if (cursor) params.append('cursor', cursor);

      const response = await api.get(`/tasks?${params.toString()}`);
      return response.data;
    } catch (error) {
      console.error('Get tasks error:', error);
      throw new Error('Failed to fetch tasks');
    }
  }

  async getTask(id: string): Promise<Task> {
    try {
      const response = await api.get(`/tasks/${id}`);
      return response.data;
    } catch (error) {
      console.error('Get task error:', error);
      throw new Error('Failed to fetch task details');
    }
  }

  async submitTask(id: string, answers: Record<string, any>): Promise<TaskSubmissionResponse> {
    try {
      const response = await api.post(`/tasks/${id}/submit`, { answers });
      return response.data;
    } catch (error) {
      console.error('Submit task error:', error);
      throw new Error('Failed to submit task');
    }
  }
}

export const taskService = new TaskService();