import axios, { AxiosInstance } from 'axios';
import * as SecureStore from 'expo-secure-store';
import { authService } from './auth';

const API_URL = process.env.EXPO_PUBLIC_API_URL || 'https://api.taskcash.app/v1';

class ApiService {
  private client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_URL,
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // Request interceptor to add auth token
    this.client.interceptors.request.use(async (config) => {
      const token = await SecureStore.getItemAsync('auth_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });

    // Response interceptor for token refresh
    this.client.interceptors.response.use(
      (response) => response,
      async (error) => {
        const originalRequest = error.config;

        if (error.response?.status === 401 && !originalRequest._retry) {
          originalRequest._retry = true;

          try {
            const refreshToken = await SecureStore.getItemAsync('refresh_token');
            if (refreshToken) {
              const tokens = await authService.refreshToken(refreshToken);
              await SecureStore.setItemAsync('auth_token', tokens.token);
              await SecureStore.setItemAsync('refresh_token', tokens.refreshToken);
              
              originalRequest.headers.Authorization = `Bearer ${tokens.token}`;
              return this.client(originalRequest);
            }
          } catch (refreshError) {
            // Refresh failed, sign out user
            await SecureStore.deleteItemAsync('auth_token');
            await SecureStore.deleteItemAsync('refresh_token');
            // TODO: Redirect to auth screen
          }
        }

        return Promise.reject(error);
      }
    );
  }

  get(url: string, config?: any) {
    return this.client.get(url, config);
  }

  post(url: string, data?: any, config?: any) {
    return this.client.post(url, data, config);
  }

  put(url: string, data?: any, config?: any) {
    return this.client.put(url, data, config);
  }

  delete(url: string, config?: any) {
    return this.client.delete(url, config);
  }
}

export const api = new ApiService();