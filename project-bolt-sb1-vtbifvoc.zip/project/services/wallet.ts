import { api } from './api';

interface WalletData {
  balance: number;
  transactions: Array<{
    id: string;
    type: 'task_completed' | 'referral_bonus' | 'withdrawal';
    amount: number;
    description: string;
    timestamp: string;
    status: 'pending' | 'completed' | 'failed';
  }>;
  withdrawals?: Array<{
    id: string;
    method: 'paypal' | 'sepa';
    value: string;
    amount: number;
    status: 'pending' | 'processing' | 'paid' | 'failed';
    createdAt: string;
  }>;
}

interface WithdrawalRequest {
  method: 'paypal' | 'sepa';
  value: string;
  amount: number;
}

class WalletService {
  async getWallet(): Promise<WalletData> {
    try {
      const response = await api.get('/wallet');
      return response.data;
    } catch (error) {
      console.error('Get wallet error:', error);
      throw new Error('Failed to fetch wallet data');
    }
  }

  async createWithdrawal(request: WithdrawalRequest) {
    try {
      const response = await api.post('/withdraw', request);
      return response.data;
    } catch (error) {
      console.error('Create withdrawal error:', error);
      throw new Error('Failed to create withdrawal request');
    }
  }
}

export const walletService = new WalletService();