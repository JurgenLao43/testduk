import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import { useTheme } from '@/constants/theme';
import { TaskStep } from '@/types/task';
import { Star } from 'lucide-react-native';

interface TaskStepRendererProps {
  step: TaskStep;
  answer: any;
  onAnswer: (answer: any) => void;
}

export function TaskStepRenderer({ step, answer, onAnswer }: TaskStepRendererProps) {
  const theme = useTheme();

  const renderSingleChoice = () => (
    <View style={styles.optionsContainer}>
      {step.options?.map((option, index) => (
        <TouchableOpacity
          key={index}
          style={[
            styles.optionButton,
            {
              backgroundColor: answer === option ? theme.colors.primary : theme.colors.background,
              borderColor: answer === option ? theme.colors.primary : theme.colors.border,
            },
          ]}
          onPress={() => onAnswer(option)}
          accessibilityLabel={`Option: ${option}`}
          accessibilityState={{ selected: answer === option }}
        >
          <Text
            style={[
              styles.optionText,
              { color: answer === option ? theme.colors.surface : theme.colors.textPrimary },
            ]}
          >
            {option}
          </Text>
        </TouchableOpacity>
      ))}
    </View>
  );

  const renderMultiChoice = () => {
    const selectedOptions = answer || [];
    
    return (
      <View style={styles.optionsContainer}>
        {step.options?.map((option, index) => (
          <TouchableOpacity
            key={index}
            style={[
              styles.optionButton,
              {
                backgroundColor: selectedOptions.includes(option) 
                  ? theme.colors.primary 
                  : theme.colors.background,
                borderColor: selectedOptions.includes(option) 
                  ? theme.colors.primary 
                  : theme.colors.border,
              },
            ]}
            onPress={() => {
              const newSelection = selectedOptions.includes(option)
                ? selectedOptions.filter((o: string) => o !== option)
                : [...selectedOptions, option];
              onAnswer(newSelection);
            }}
            accessibilityLabel={`Option: ${option}`}
            accessibilityState={{ selected: selectedOptions.includes(option) }}
          >
            <Text
              style={[
                styles.optionText,
                { 
                  color: selectedOptions.includes(option) 
                    ? theme.colors.surface 
                    : theme.colors.textPrimary 
                },
              ]}
            >
              {option}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const renderTextInput = () => (
    <TextInput
      style={[
        styles.textInput,
        {
          backgroundColor: theme.colors.background,
          borderColor: theme.colors.border,
          color: theme.colors.textPrimary,
        },
      ]}
      placeholder="Enter your answer..."
      placeholderTextColor={theme.colors.textSecondary}
      value={answer || ''}
      onChangeText={onAnswer}
      multiline
      numberOfLines={4}
      maxLength={step.validation?.maxLength || 500}
      clearButtonMode="while-editing"
      accessibilityLabel={`Text input for: ${step.question}`}
    />
  );

  const renderRating = () => {
    const rating = answer || 0;
    
    return (
      <View style={styles.ratingContainer}>
        {[1, 2, 3, 4, 5].map((star) => (
          <TouchableOpacity
            key={star}
            onPress={() => onAnswer(star)}
            style={styles.starButton}
            accessibilityLabel={`Rate ${star} out of 5 stars`}
            accessibilityState={{ selected: star <= rating }}
          >
            <Star
              size={32}
              color={star <= rating ? theme.colors.accent : theme.colors.border}
              fill={star <= rating ? theme.colors.accent : 'transparent'}
            />
          </TouchableOpacity>
        ))}
      </View>
    );
  };

  const renderStepContent = () => {
    switch (step.type) {
      case 'single-choice':
        return renderSingleChoice();
      case 'multi-choice':
        return renderMultiChoice();
      case 'text':
        return renderTextInput();
      case 'rating':
        return renderRating();
      case 'photo':
        return (
          <Text style={[styles.placeholder, { color: theme.colors.textSecondary }]}>
            Photo upload coming soon
          </Text>
        );
      case 'link':
        return (
          <Text style={[styles.placeholder, { color: theme.colors.textSecondary }]}>
            External link task coming soon
          </Text>
        );
      default:
        return null;
    }
  };

  return (
    <View style={styles.container}>
      <Text style={[styles.question, { color: theme.colors.textPrimary }]}>
        {step.question}
      </Text>
      {step.required && (
        <Text style={[styles.required, { color: theme.colors.error }]}>
          * Required
        </Text>
      )}
      
      <View style={styles.content}>
        {renderStepContent()}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  question: {
    fontSize: 24,
    fontWeight: '600',
    lineHeight: 30,
    marginBottom: 8,
  },
  required: {
    fontSize: 13,
    marginBottom: 24,
  },
  content: {
    flex: 1,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
  },
  optionText: {
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
  },
  textInput: {
    borderRadius: 12,
    borderWidth: 1,
    padding: 16,
    fontSize: 16,
    textAlignVertical: 'top',
    minHeight: 120,
  },
  ratingContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 24,
  },
  starButton: {
    padding: 8,
  },
  placeholder: {
    fontSize: 16,
    textAlign: 'center',
    fontStyle: 'italic',
    paddingVertical: 48,
  },
});