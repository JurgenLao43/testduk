import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';
import { VictoryChart, VictoryLine, VictoryAxis } from 'victory-native';
import { useTheme } from '@/constants/theme';

const { width } = Dimensions.get('window');

// Mock data for 14 days
const generateMockData = () => {
  const data = [];
  const now = new Date();
  
  for (let i = 13; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    data.push({
      x: date,
      y: Math.max(0, Math.random() * 50 + i * 2), // Trending upward
    });
  }
  
  return data;
};

export function BalanceChart() {
  const theme = useTheme();
  const data = generateMockData();

  return (
    <View style={styles.container}>
      <VictoryChart
        width={width - 80}
        height={200}
        padding={{ left: 50, top: 20, right: 20, bottom: 40 }}
      >
        <VictoryAxis
          dependentAxis
          tickFormat={(value) => `$${value.toFixed(0)}`}
          style={{
            tickLabels: { 
              fontSize: 12, 
              fill: theme.colors.textSecondary,
              fontFamily: 'System',
            },
            grid: { stroke: theme.colors.border, strokeWidth: 0.5 },
            axis: { stroke: 'transparent' },
          }}
        />
        <VictoryAxis
          tickFormat={() => ''}
          style={{
            axis: { stroke: 'transparent' },
            ticks: { stroke: 'transparent' },
          }}
        />
        <VictoryLine
          data={data}
          style={{
            data: { 
              stroke: theme.colors.primary, 
              strokeWidth: 3,
            },
          }}
          animate={{
            duration: 1000,
            onLoad: { duration: 500 }
          }}
        />
      </VictoryChart>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
  },
});