import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableOpacity,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { useTheme } from '@/constants/theme';
import { useWalletStore } from '@/store/wallet';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { formatCurrency } from '@/utils/money';
import { X, CreditCard, Building } from 'lucide-react-native';

interface WithdrawModalProps {
  visible: boolean;
  onClose: () => void;
  balance: number;
}

export function WithdrawModal({ visible, onClose, balance }: WithdrawModalProps) {
  const theme = useTheme();
  const [method, setMethod] = useState<'paypal' | 'sepa'>('paypal');
  const [paypalEmail, setPaypalEmail] = useState('');
  const [iban, setIban] = useState('');
  const [swift, setSwift] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { withdraw } = useWalletStore();

  const handleSubmit = async () => {
    try {
      setIsSubmitting(true);
      
      if (method === 'paypal') {
        if (!paypalEmail.trim()) {
          Alert.alert('Error', 'Please enter your PayPal email.');
          return;
        }
        await withdraw('paypal', paypalEmail, balance);
      } else {
        if (!iban.trim() || !swift.trim()) {
          Alert.alert('Error', 'Please enter both IBAN and SWIFT code.');
          return;
        }
        await withdraw('sepa', `${iban}|${swift}`, balance);
      }
      
      Alert.alert(
        'Withdrawal Submitted',
        'Your withdrawal request has been submitted and is being processed.',
        [{ text: 'OK', onPress: onClose }]
      );
    } catch (error: any) {
      Alert.alert('Withdrawal Failed', error.message || 'Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setPaypalEmail('');
    setIban('');
    setSwift('');
    setMethod('paypal');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={handleClose}
    >
      <KeyboardAvoidingView 
        style={[styles.container, { backgroundColor: theme.colors.background }]}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={[styles.header, { backgroundColor: theme.colors.surface }]}>
          <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
            <X size={24} color={theme.colors.textPrimary} />
          </TouchableOpacity>
          <Text style={[styles.headerTitle, { color: theme.colors.textPrimary }]}>
            Withdraw Funds
          </Text>
          <View style={styles.placeholder} />
        </View>

        <View style={styles.content}>
          <View style={[styles.balanceCard, { backgroundColor: theme.colors.surface }]}>
            <Text style={[styles.balanceLabel, { color: theme.colors.textSecondary }]}>
              Available to withdraw
            </Text>
            <Text style={[styles.balanceAmount, { color: theme.colors.textPrimary }]}>
              {formatCurrency(balance)}
            </Text>
          </View>

          <View style={[styles.methodCard, { backgroundColor: theme.colors.surface }]}>
            <Text style={[styles.methodTitle, { color: theme.colors.textPrimary }]}>
              Withdrawal Method
            </Text>
            
            <View style={styles.methodSelector}>
              <TouchableOpacity
                style={[
                  styles.methodOption,
                  {
                    backgroundColor: method === 'paypal' ? theme.colors.primary : theme.colors.background,
                    borderColor: method === 'paypal' ? theme.colors.primary : theme.colors.border,
                  },
                ]}
                onPress={() => setMethod('paypal')}
                accessibilityLabel="Select PayPal withdrawal method"
              >
                <CreditCard size={20} color={method === 'paypal' ? theme.colors.surface : theme.colors.textSecondary} />
                <Text style={[
                  styles.methodText,
                  { color: method === 'paypal' ? theme.colors.surface : theme.colors.textPrimary }
                ]}>
                  PayPal
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[
                  styles.methodOption,
                  {
                    backgroundColor: method === 'sepa' ? theme.colors.primary : theme.colors.background,
                    borderColor: method === 'sepa' ? theme.colors.primary : theme.colors.border,
                  },
                ]}
                onPress={() => setMethod('sepa')}
                accessibilityLabel="Select bank transfer withdrawal method"
              >
                <Building size={20} color={method === 'sepa' ? theme.colors.surface : theme.colors.textSecondary} />
                <Text style={[
                  styles.methodText,
                  { color: method === 'sepa' ? theme.colors.surface : theme.colors.textPrimary }
                ]}>
                  Bank Transfer
                </Text>
              </TouchableOpacity>
            </View>

            {method === 'paypal' ? (
              <TextInput
                style={[styles.input, { 
                  backgroundColor: theme.colors.background,
                  borderColor: theme.colors.border,
                  color: theme.colors.textPrimary,
                }]}
                placeholder="PayPal email address"
                placeholderTextColor={theme.colors.textSecondary}
                value={paypalEmail}
                onChangeText={setPaypalEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
                clearButtonMode="while-editing"
                textContentType="emailAddress"
              />
            ) : (
              <>
                <TextInput
                  style={[styles.input, { 
                    backgroundColor: theme.colors.background,
                    borderColor: theme.colors.border,
                    color: theme.colors.textPrimary,
                  }]}
                  placeholder="IBAN"
                  placeholderTextColor={theme.colors.textSecondary}
                  value={iban}
                  onChangeText={setIban}
                  autoCapitalize="characters"
                  autoCorrect={false}
                  clearButtonMode="while-editing"
                />
                <TextInput
                  style={[styles.input, { 
                    backgroundColor: theme.colors.background,
                    borderColor: theme.colors.border,
                    color: theme.colors.textPrimary,
                  }]}
                  placeholder="SWIFT/BIC Code"
                  placeholderTextColor={theme.colors.textSecondary}
                  value={swift}
                  onChangeText={setSwift}
                  autoCapitalize="characters"
                  autoCorrect={false}
                  clearButtonMode="while-editing"
                />
              </>
            )}
          </View>

          <PrimaryButton
            title={`Withdraw ${formatCurrency(balance)}`}
            onPress={handleSubmit}
            disabled={isSubmitting || (!paypalEmail.trim() && method === 'paypal') || (!iban.trim() || !swift.trim()) && method === 'sepa'}
            loading={isSubmitting}
            style={styles.submitButton}
          />

          <Text style={[styles.disclaimer, { color: theme.colors.textSecondary }]}>
            Withdrawals typically process within 1-3 business days. A small processing fee may apply.
          </Text>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 60,
    paddingBottom: 16,
    paddingHorizontal: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 2,
  },
  closeButton: {
    width: 32,
    height: 32,
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  placeholder: {
    width: 32,
  },
  content: {
    flex: 1,
    padding: 24,
  },
  balanceCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  balanceLabel: {
    fontSize: 16,
    marginBottom: 8,
  },
  balanceAmount: {
    fontSize: 32,
    fontWeight: '700',
  },
  methodCard: {
    borderRadius: 16,
    padding: 24,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  methodTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 16,
  },
  methodSelector: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  methodOption: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
  },
  methodText: {
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 8,
  },
  input: {
    height: 48,
    borderRadius: 12,
    borderWidth: 1,
    paddingHorizontal: 16,
    fontSize: 16,
    marginBottom: 16,
  },
  submitButton: {
    marginBottom: 16,
  },
  disclaimer: {
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 18,
  },
});