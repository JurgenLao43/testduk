import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
} from 'react-native';
import { useTheme } from '@/constants/theme';
import { formatCurrency } from '@/utils/money';
import { formatDistanceToNow } from 'date-fns';
import { CircleCheck as CheckCircle, Clock, Users } from 'lucide-react-native';

interface Transaction {
  id: string;
  type: 'task_completed' | 'referral_bonus' | 'withdrawal';
  amount: number;
  description: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
}

interface TransactionListProps {
  transactions: Transaction[];
}

const TransactionItem = React.memo(({ item }: { item: Transaction }) => {
  const theme = useTheme();

  const getTransactionIcon = (type: string, status: string) => {
    if (status === 'pending') {
      return <Clock size={20} color={theme.colors.textSecondary} />;
    }
    
    switch (type) {
      case 'task_completed':
        return <CheckCircle size={20} color={theme.colors.success} />;
      case 'referral_bonus':
        return <Users size={20} color={theme.colors.accent} />;
      case 'withdrawal':
        return <CheckCircle size={20} color={theme.colors.primary} />;
      default:
        return <CheckCircle size={20} color={theme.colors.success} />;
    }
  };

  const getAmountColor = (type: string, amount: number) => {
    if (type === 'withdrawal') {
      return theme.colors.error;
    }
    return amount > 0 ? theme.colors.success : theme.colors.error;
  };

  const formatAmount = (type: string, amount: number) => {
    const prefix = type === 'withdrawal' ? '-' : '+';
    return `${prefix}${formatCurrency(Math.abs(amount))}`;
  };

  return (
    <View style={styles.transactionItem}>
      <View style={styles.transactionLeft}>
        {getTransactionIcon(item.type, item.status)}
        <View style={styles.transactionInfo}>
          <Text style={[styles.transactionDescription, { color: theme.colors.textPrimary }]}>
            {item.description}
          </Text>
          <Text style={[styles.transactionTime, { color: theme.colors.textSecondary }]}>
            {formatDistanceToNow(new Date(item.timestamp), { addSuffix: true })}
          </Text>
        </View>
      </View>
      <Text style={[
        styles.transactionAmount,
        { color: getAmountColor(item.type, item.amount) }
      ]}>
        {formatAmount(item.type, item.amount)}
      </Text>
    </View>
  );
});

export function TransactionList({ transactions }: TransactionListProps) {
  const theme = useTheme();

  if (transactions.length === 0) {
    return (
      <View style={styles.emptyState}>
        <Text style={[styles.emptyText, { color: theme.colors.textSecondary }]}>
          No transactions yet
        </Text>
      </View>
    );
  }

  return (
    <FlatList
      data={transactions}
      renderItem={({ item }) => <TransactionItem item={item} />}
      keyExtractor={(item) => item.id}
      style={styles.list}
      showsVerticalScrollIndicator={false}
      windowSize={10}
      initialNumToRender={8}
      maxToRenderPerBatch={5}
      removeClippedSubviews={true}
    />
  );
}

const styles = StyleSheet.create({
  list: {
    maxHeight: 300,
  },
  transactionItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 0.5,
    borderBottomColor: 'rgba(0,0,0,0.05)',
  },
  transactionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  transactionInfo: {
    marginLeft: 12,
    flex: 1,
  },
  transactionDescription: {
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 2,
  },
  transactionTime: {
    fontSize: 13,
  },
  transactionAmount: {
    fontSize: 16,
    fontWeight: '600',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 32,
  },
  emptyText: {
    fontSize: 16,
  },
});