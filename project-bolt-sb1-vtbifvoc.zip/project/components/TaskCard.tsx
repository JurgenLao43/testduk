import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
} from 'react-native';
import { useTheme } from '@/constants/theme';
import { Task } from '@/types/task';
import { formatCurrency } from '@/utils/money';
import { Clock, Star } from 'lucide-react-native';
import { MotiView } from 'moti';

interface TaskCardProps {
  task: Task;
  onPress: () => void;
}

export function TaskCard({ task, onPress }: TaskCardProps) {
  const theme = useTheme();

  const getTagColor = (tag: string) => {
    switch (tag) {
      case 'survey': return theme.colors.primary;
      case 'game': return theme.colors.accent;
      case 'offer': return theme.colors.success;
      case 'receipt': return theme.colors.warning;
      default: return theme.colors.textSecondary;
    }
  };

  return (
    <MotiView
      from={{ opacity: 0, translateY: 8 }}
      animate={{ opacity: 1, translateY: 0 }}
      transition={{ type: 'timing', duration: 160 }}
    >
      <TouchableOpacity
        style={[styles.card, { backgroundColor: theme.colors.surface }]}
        onPress={onPress}
        activeOpacity={0.9}
        accessibilityLabel={`Task: ${task.title}, Payout: ${formatCurrency(task.payout)}, Estimated time: ${task.estimatedMinutes} minutes`}
      >
        <View style={styles.cardHeader}>
          <Image
            source={{ uri: task.brandLogo }}
            style={styles.brandLogo}
            defaultSource={require('@/assets/images/placeholder-logo.png')}
          />
          <View style={styles.taskInfo}>
            <Text style={[styles.taskTitle, { color: theme.colors.textPrimary }]}>
              {task.title}
            </Text>
            <View style={styles.taskMeta}>
              <Clock size={12} color={theme.colors.textSecondary} />
              <Text style={[styles.etaText, { color: theme.colors.textSecondary }]}>
                {task.estimatedMinutes}m
              </Text>
              <View style={[styles.tag, { backgroundColor: getTagColor(task.tag) }]}>
                <Text style={[styles.tagText, { color: theme.colors.surface }]}>
                  {task.tag}
                </Text>
              </View>
            </View>
          </View>
          <View style={styles.payoutContainer}>
            <Text style={[styles.payoutAmount, { color: theme.colors.accent }]}>
              {formatCurrency(task.payout)}
            </Text>
            {task.featured && (
              <Star size={16} color={theme.colors.accent} fill={theme.colors.accent} />
            )}
          </View>
        </View>
        
        {task.description && (
          <Text style={[styles.description, { color: theme.colors.textSecondary }]}>
            {task.description}
          </Text>
        )}
      </TouchableOpacity>
    </MotiView>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  brandLogo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginRight: 12,
  },
  taskInfo: {
    flex: 1,
  },
  taskTitle: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  taskMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  etaText: {
    fontSize: 12,
    fontWeight: '500',
  },
  tag: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 6,
  },
  tagText: {
    fontSize: 10,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  payoutContainer: {
    alignItems: 'flex-end',
  },
  payoutAmount: {
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  description: {
    fontSize: 14,
    marginTop: 12,
    lineHeight: 20,
  },
});