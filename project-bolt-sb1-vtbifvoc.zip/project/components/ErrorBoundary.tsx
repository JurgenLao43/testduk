import React, { Component, ReactNode } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { PrimaryButton } from '@/components/ui/PrimaryButton';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: any) {
    console.error('Error Boundary caught an error:', error, errorInfo);
    // TODO: Report to Sentry
  }

  render() {
    if (this.state.hasError) {
      return (
        <View style={styles.container}>
          <Text style={styles.title}>Something went wrong</Text>
          <Text style={styles.description}>
            We're sorry, but something unexpected happened. Please try restarting the app.
          </Text>
          <PrimaryButton
            title="Restart App"
            onPress={() => this.setState({ hasError: false })}
            style={styles.button}
          />
        </View>
      );
    }

    return this.props.children;
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    backgroundColor: '#F5F5F7',
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    color: '#0D0D0D',
    textAlign: 'center',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#666A75',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 32,
  },
  button: {
    minWidth: 160,
  },
});