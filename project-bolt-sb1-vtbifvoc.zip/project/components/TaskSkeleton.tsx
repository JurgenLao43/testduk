import React from 'react';
import { View, StyleSheet } from 'react-native';
import { useTheme } from '@/constants/theme';
import { MotiView } from 'moti';

export function TaskSkeleton() {
  const theme = useTheme();

  return (
    <View style={[styles.card, { backgroundColor: theme.colors.surface }]}>
      <View style={styles.cardHeader}>
        <MotiView
          style={[styles.logo, { backgroundColor: theme.colors.border }]}
          from={{ opacity: 0.3 }}
          animate={{ opacity: 0.7 }}
          transition={{
            type: 'timing',
            duration: 1000,
            loop: true,
          }}
        />
        <View style={styles.taskInfo}>
          <MotiView
            style={[styles.titleSkeleton, { backgroundColor: theme.colors.border }]}
            from={{ opacity: 0.3 }}
            animate={{ opacity: 0.7 }}
            transition={{
              type: 'timing',
              duration: 1000,
              loop: true,
            }}
          />
          <MotiView
            style={[styles.metaSkeleton, { backgroundColor: theme.colors.border }]}
            from={{ opacity: 0.3 }}
            animate={{ opacity: 0.7 }}
            transition={{
              type: 'timing',
              duration: 1000,
              loop: true,
              delay: 200,
            }}
          />
        </View>
        <MotiView
          style={[styles.payoutSkeleton, { backgroundColor: theme.colors.border }]}
          from={{ opacity: 0.3 }}
          animate={{ opacity: 0.7 }}
          transition={{
            type: 'timing',
            duration: 1000,
            loop: true,
            delay: 400,
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  logo: {
    width: 40,
    height: 40,
    borderRadius: 8,
    marginRight: 12,
  },
  taskInfo: {
    flex: 1,
  },
  titleSkeleton: {
    height: 16,
    borderRadius: 4,
    marginBottom: 8,
    width: '80%',
  },
  metaSkeleton: {
    height: 12,
    borderRadius: 4,
    width: '60%',
  },
  payoutSkeleton: {
    width: 50,
    height: 20,
    borderRadius: 4,
  },
});