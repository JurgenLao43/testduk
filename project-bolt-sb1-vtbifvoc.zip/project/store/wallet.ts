import { create } from 'zustand';
import { walletService } from '@/services/wallet';

interface Transaction {
  id: string;
  type: 'task_completed' | 'referral_bonus' | 'withdrawal';
  amount: number;
  description: string;
  timestamp: string;
  status: 'pending' | 'completed' | 'failed';
}

interface WithdrawalRequest {
  id: string;
  method: 'paypal' | 'sepa';
  value: string; // email or IBAN
  amount: number;
  status: 'pending' | 'processing' | 'paid' | 'failed';
  createdAt: string;
}

interface WalletState {
  balance: number;
  transactions: Transaction[];
  withdrawals: WithdrawalRequest[];
  isLoading: boolean;
  error: string | null;
  
  fetchWallet: () => Promise<void>;
  withdraw: (method: 'paypal' | 'sepa', value: string, amount: number) => Promise<void>;
  addTransaction: (transaction: Transaction) => void;
  updateBalance: (newBalance: number) => void;
}

export const useWalletStore = create<WalletState>((set, get) => ({
  balance: 0,
  transactions: [],
  withdrawals: [],
  isLoading: false,
  error: null,

  fetchWallet: async () => {
    try {
      set({ isLoading: true, error: null });
      const walletData = await walletService.getWallet();
      set({ 
        balance: walletData.balance,
        transactions: walletData.transactions,
        withdrawals: walletData.withdrawals || [],
        isLoading: false,
      });
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
    }
  },

  withdraw: async (method, value, amount) => {
    try {
      set({ isLoading: true, error: null });
      const withdrawal = await walletService.createWithdrawal({ method, value, amount });
      
      set(state => ({
        withdrawals: [withdrawal, ...state.withdrawals],
        balance: state.balance - amount,
        isLoading: false,
      }));
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  addTransaction: (transaction) => {
    set(state => ({
      transactions: [transaction, ...state.transactions],
    }));
  },

  updateBalance: (newBalance) => {
    set({ balance: newBalance });
  },
}));