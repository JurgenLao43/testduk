import React, { createContext, useContext, useEffect, ReactNode } from 'react';
import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import * as AppleAuthentication from 'expo-apple-authentication';
import { router } from 'expo-router';
import { authService } from '@/services/auth';

interface User {
  id: string;
  email: string;
  displayName?: string;
  avatar?: string;
  referralCode: string;
  deviceInfo?: string;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  signInWithApple: (credential: AppleAuthentication.AppleAuthenticationCredential) => Promise<void>;
  signInWithEmail: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
  loadStoredAuth: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isLoading: false,
  isAuthenticated: false,

  signInWithApple: async (credential) => {
    try {
      set({ isLoading: true });
      const response = await authService.signInWithApple(credential);
      
      await SecureStore.setItemAsync('auth_token', response.token);
      await SecureStore.setItemAsync('refresh_token', response.refreshToken);
      
      set({ 
        user: response.user, 
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  signInWithEmail: async (email) => {
    try {
      set({ isLoading: true });
      await authService.sendMagicLink(email);
      set({ isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  signOut: async () => {
    try {
      await SecureStore.deleteItemAsync('auth_token');
      await SecureStore.deleteItemAsync('refresh_token');
      set({ user: null, isAuthenticated: false });
    } catch (error) {
      console.error('Sign out error:', error);
    }
  },

  loadStoredAuth: async () => {
    try {
      set({ isLoading: true });
      const token = await SecureStore.getItemAsync('auth_token');
      
      if (token) {
        const user = await authService.validateToken(token);
        set({ user, isAuthenticated: true });
      }
    } catch (error) {
      console.error('Load stored auth error:', error);
      await get().signOut();
    } finally {
      set({ isLoading: false });
    }
  },
}));

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const { isAuthenticated, isLoading, loadStoredAuth } = useAuthStore();

  useEffect(() => {
    loadStoredAuth();
  }, []);

  useEffect(() => {
    if (!isLoading) {
      if (isAuthenticated) {
        router.replace('/(tabs)');
      } else {
        router.replace('/(auth)');
      }
    }
  }, [isAuthenticated, isLoading]);

  return <>{children}</>;
}