import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';

interface UIState {
  pushNotificationsEnabled: boolean;
  hapticsEnabled: boolean;
  darkModeOverride: boolean;
  
  togglePushNotifications: () => void;
  toggleHaptics: () => void;
  toggleDarkModeOverride: () => void;
  loadSettings: () => Promise<void>;
}

export const useUIStore = create<UIState>((set, get) => ({
  pushNotificationsEnabled: true,
  hapticsEnabled: true,
  darkModeOverride: false,

  togglePushNotifications: () => {
    const newValue = !get().pushNotificationsEnabled;
    set({ pushNotificationsEnabled: newValue });
    SecureStore.setItemAsync('pushNotificationsEnabled', String(newValue));
  },

  toggleHaptics: () => {
    const newValue = !get().hapticsEnabled;
    set({ hapticsEnabled: newValue });
    SecureStore.setItemAsync('hapticsEnabled', String(newValue));
  },

  toggleDarkModeOverride: () => {
    const newValue = !get().darkModeOverride;
    set({ darkModeOverride: newValue });
    SecureStore.setItemAsync('darkModeOverride', String(newValue));
  },

  loadSettings: async () => {
    try {
      const pushEnabled = await SecureStore.getItemAsync('pushNotificationsEnabled');
      const hapticsEnabled = await SecureStore.getItemAsync('hapticsEnabled');
      const darkModeOverride = await SecureStore.getItemAsync('darkModeOverride');

      set({
        pushNotificationsEnabled: pushEnabled !== 'false',
        hapticsEnabled: hapticsEnabled !== 'false',
        darkModeOverride: darkModeOverride === 'true',
      });
    } catch (error) {
      console.error('Failed to load UI settings:', error);
    }
  },
}));