import { create } from 'zustand';
import { taskService } from '@/services/tasks';
import { Task, TaskStep, TaskSubmission } from '@/types/task';

interface TaskDraft {
  taskId: string;
  answers: Record<string, any>;
  lastSaved: string;
}

interface TasksState {
  tasks: Task[];
  currentTask: Task | null;
  drafts: TaskDraft[];
  isLoading: boolean;
  error: string | null;
  
  fetchTasks: (category: string, cursor?: string) => Promise<{ items: Task[], nextCursor?: string }>;
  fetchTask: (id: string) => Promise<Task>;
  submitTask: (id: string, answers: Record<string, any>) => Promise<{ credit: number, txId: string, newBalance: number }>;
  saveDraft: (taskId: string, answers: Record<string, any>) => void;
  loadDraft: (taskId: string) => Record<string, any> | null;
  clearDraft: (taskId: string) => void;
}

export const useTasksStore = create<TasksState>((set, get) => ({
  tasks: [],
  currentTask: null,
  drafts: [],
  isLoading: false,
  error: null,

  fetchTasks: async (category, cursor) => {
    try {
      set({ isLoading: true, error: null });
      const response = await taskService.getTasks(category, cursor);
      
      if (cursor) {
        // Append to existing tasks for pagination
        set(state => ({
          tasks: [...state.tasks, ...response.items],
          isLoading: false,
        }));
      } else {
        // Replace tasks for refresh
        set({ tasks: response.items, isLoading: false });
      }
      
      return response;
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  fetchTask: async (id) => {
    try {
      set({ isLoading: true, error: null });
      const task = await taskService.getTask(id);
      set({ currentTask: task, isLoading: false });
      return task;
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  submitTask: async (id, answers) => {
    try {
      set({ isLoading: true, error: null });
      const result = await taskService.submitTask(id, answers);
      
      // Clear draft after successful submission
      get().clearDraft(id);
      
      set({ isLoading: false });
      return result;
    } catch (error: any) {
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },

  saveDraft: (taskId, answers) => {
    const draft: TaskDraft = {
      taskId,
      answers,
      lastSaved: new Date().toISOString(),
    };
    
    set(state => ({
      drafts: [
        ...state.drafts.filter(d => d.taskId !== taskId),
        draft,
      ],
    }));
  },

  loadDraft: (taskId) => {
    const draft = get().drafts.find(d => d.taskId === taskId);
    return draft?.answers || null;
  },

  clearDraft: (taskId) => {
    set(state => ({
      drafts: state.drafts.filter(d => d.taskId !== taskId),
    }));
  },
}));