import { useInfiniteQuery } from '@tanstack/react-query';
import { useTasksStore } from '@/store/tasks';

export function useTasksQuery(category: string) {
  const { fetchTasks } = useTasksStore();

  return useInfiniteQuery({
    queryKey: ['tasks', category],
    queryFn: ({ pageParam }) => fetchTasks(category, pageParam),
    initialPageParam: undefined,
    getNextPageParam: (lastPage) => lastPage.nextCursor,
    staleTime: 15 * 60 * 1000, // 15 minutes
  });
}