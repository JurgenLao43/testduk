import { ExpoConfig, ConfigContext } from 'expo/config';

export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: 'TaskCash',
  slug: 'taskcash-ios',
  version: '1.0.0',
  orientation: 'portrait',
  icon: './assets/images/icon.png',
  scheme: 'taskcash',
  userInterfaceStyle: 'automatic',
  newArchEnabled: true,
  ios: {
    supportsTablet: false,
    bundleIdentifier: 'com.company.taskcash',
    runtimeVersion: '1.0.0',
    buildNumber: '1',
    deploymentTarget: '17.0',
    infoPlist: {
      CFBundleAllowMixedLocalizations: true,
      NSCameraUsageDescription: 'TaskCash needs camera access to scan receipts for cash rewards.',
      NSPhotoLibraryUsageDescription: 'TaskCash needs photo library access to upload receipt images.',
    },
  },
  web: {
    bundler: 'metro',
    output: 'single',
    favicon: './assets/images/favicon.png',
  },
  plugins: [
    'expo-router',
    'expo-font',
    'expo-secure-store',
    'expo-sqlite',
    'expo-notifications',
    'expo-apple-authentication',
    'expo-camera',
  ],
  experiments: {
    typedRoutes: true,
  },
  extra: {
    eas: {
      projectId: 'your-project-id-here',
    },
  },
});