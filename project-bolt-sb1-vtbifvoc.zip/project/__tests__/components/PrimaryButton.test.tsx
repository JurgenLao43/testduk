import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { PrimaryButton } from '@/components/ui/PrimaryButton';
import { ThemeProvider } from '@/constants/theme';

const TestWrapper = ({ children }: { children: React.ReactNode }) => (
  <ThemeProvider>{children}</ThemeProvider>
);

describe('PrimaryButton', () => {
  it('renders correctly with title', () => {
    const { getByText } = render(
      <TestWrapper>
        <PrimaryButton title="Test Button" onPress={jest.fn()} />
      </TestWrapper>
    );

    expect(getByText('Test Button')).toBeTruthy();
  });

  it('calls onPress when pressed', () => {
    const onPressMock = jest.fn();
    const { getByText } = render(
      <TestWrapper>
        <PrimaryButton title="Test Button" onPress={onPressMock} />
      </TestWrapper>
    );

    fireEvent.press(getByText('Test Button'));
    expect(onPressMock).toHaveBeenCalledTimes(1);
  });

  it('does not call onPress when disabled', () => {
    const onPressMock = jest.fn();
    const { getByText } = render(
      <TestWrapper>
        <PrimaryButton title="Test Button" onPress={onPressMock} disabled />
      </TestWrapper>
    );

    fireEvent.press(getByText('Test Button'));
    expect(onPressMock).not.toHaveBeenCalled();
  });

  it('shows loading indicator when loading', () => {
    const { getByTestId } = render(
      <TestWrapper>
        <PrimaryButton title="Test Button" onPress={jest.fn()} loading />
      </TestWrapper>
    );

    expect(getByTestId('activity-indicator')).toBeTruthy();
  });
});