import { useTasksStore } from '@/store/tasks';
import { taskService } from '@/services/tasks';

// Mock the task service
jest.mock('@/services/tasks', () => ({
  taskService: {
    getTasks: jest.fn(),
    getTask: jest.fn(),
    submitTask: jest.fn(),
  },
}));

const mockedTaskService = taskService as jest.Mocked<typeof taskService>;

describe('TasksStore', () => {
  beforeEach(() => {
    // Reset store state
    useTasksStore.setState({
      tasks: [],
      currentTask: null,
      drafts: [],
      isLoading: false,
      error: null,
    });
    
    jest.clearAllMocks();
  });

  describe('fetchTasks', () => {
    it('should fetch tasks successfully', async () => {
      const mockTasks = [
        {
          id: '1',
          title: 'Test Task',
          payout: 0.5,
          estimatedMinutes: 5,
          tag: 'survey' as const,
          featured: false,
          brandLogo: 'https://example.com/logo.png',
        },
      ];
      
      mockedTaskService.getTasks.mockResolvedValue({
        items: mockTasks,
        nextCursor: 'cursor-123',
      });

      const store = useTasksStore.getState();
      const result = await store.fetchTasks('featured');

      expect(mockedTaskService.getTasks).toHaveBeenCalledWith('featured', undefined);
      expect(result.items).toEqual(mockTasks);
      expect(result.nextCursor).toBe('cursor-123');
      expect(useTasksStore.getState().tasks).toEqual(mockTasks);
      expect(useTasksStore.getState().isLoading).toBe(false);
    });

    it('should handle fetch tasks error', async () => {
      mockedTaskService.getTasks.mockRejectedValue(new Error('Network error'));

      const store = useTasksStore.getState();
      
      await expect(store.fetchTasks('featured')).rejects.toThrow('Network error');
      expect(useTasksStore.getState().error).toBe('Network error');
      expect(useTasksStore.getState().isLoading).toBe(false);
    });
  });

  describe('saveDraft and loadDraft', () => {
    it('should save and load drafts correctly', () => {
      const store = useTasksStore.getState();
      const taskId = 'task-123';
      const answers = { question1: 'answer1', question2: 'answer2' };

      store.saveDraft(taskId, answers);

      const loadedDraft = store.loadDraft(taskId);
      expect(loadedDraft).toEqual(answers);

      const state = useTasksStore.getState();
      expect(state.drafts).toHaveLength(1);
      expect(state.drafts[0].taskId).toBe(taskId);
      expect(state.drafts[0].answers).toEqual(answers);
    });

    it('should clear drafts correctly', () => {
      const store = useTasksStore.getState();
      const taskId = 'task-123';
      const answers = { question1: 'answer1' };

      store.saveDraft(taskId, answers);
      expect(useTasksStore.getState().drafts).toHaveLength(1);

      store.clearDraft(taskId);
      expect(useTasksStore.getState().drafts).toHaveLength(0);
    });
  });
});