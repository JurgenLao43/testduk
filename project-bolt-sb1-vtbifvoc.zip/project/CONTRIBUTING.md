# Contributing to TaskCash iOS

Thank you for your interest in contributing to TaskCash! This document provides guidelines for contributing to the project.

## Development Setup

1. Fork the repository
2. Clone your fork: `git clone https://github.com/yourusername/taskcash-ios.git`
3. Install dependencies: `npm install`
4. Start the development server: `npm run dev`

## Code Style

- Use TypeScript strict mode
- Follow ESLint and Prettier configurations
- Write meaningful commit messages
- Add tests for new features

## Pull Request Process

1. Create a feature branch from `develop`
2. Make your changes
3. Add tests if applicable
4. Ensure all tests pass: `npm test`
5. Run linting: `npm run lint`
6. Submit a pull request to `develop` branch

## Testing

- Write unit tests for utility functions
- Add integration tests for complex components
- Ensure minimum 95% test coverage

## Reporting Issues

- Use the provided issue templates
- Include device information and steps to reproduce
- Add screenshots when helpful

## Code of Conduct

Be respectful, inclusive, and constructive in all interactions.